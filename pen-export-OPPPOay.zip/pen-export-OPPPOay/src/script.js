// Dati di esempio per gli utenti (Admin e Clienti)
const users = {
  admin: {
    username: "admin",
    password: "admin123",
    name: "Admin",
    clients: [
      {
        username: "mehmed",
        name: "Mehmed Omerovic",
        trainingPlan: "Piano Base",
        schedule: []
      },
      {
        username: "giordie",
        name: "Giordie",
        trainingPlan: "Piano Intermedio",
        schedule: []
      },
      {
        username: "bruno",
        name: "Bruno",
        trainingPlan: "Piano Avanzato",
        schedule: []
      }
    ]
  }
};

// Elementi del DOM
const loginBtn = document.getElementById("login-btn");
const loginMessage = document.getElementById("login-message");
const appPage = document.getElementById("app-page");
const loginPage = document.getElementById("login-page");
const userNameSpan = document.getElementById("user-name");
const adminSection = document.getElementById("admin-section");
const clientSection = document.getElementById("client-section");

// Login
loginBtn.addEventListener("click", () => {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Reset messaggio login
  loginMessage.textContent = "";

  if (username === users.admin.username && password === users.admin.password) {
    // Admin login
    loginPage.style.display = "none";
    appPage.style.display = "block";
    userNameSpan.textContent = "Admin";

    // Mostra la sezione Admin
    adminSection.style.display = "block";
    clientSection.style.display = "none";

    // Mostra la lista dei clienti
    const clientList = document.getElementById("client-list-ul");
    clientList.innerHTML = ""; // Clear the list first
    users.admin.clients.forEach((client) => {
      const listItem = document.createElement("li");
      listItem.textContent = `${client.name} - Piano: ${client.trainingPlan}`;
      clientList.appendChild(listItem);
    });
  } else {
    // Verifica se il login è per un cliente
    const client = users.admin.clients.find(
      (client) => client.username === username && client.password === password
    );
    if (client) {
      // Client login
      loginPage.style.display = "none";
      appPage.style.display = "block";
      userNameSpan.textContent = client.name;

      // Mostra la sezione Client
      adminSection.style.display = "none";
      clientSection.style.display = "block";

      // Visualizza il piano di allenamento del cliente
      const clientPlanList = document.getElementById("client-plan");
      clientPlanList.innerHTML = ""; // Clear the list first
      const planItem = document.createElement("li");
      planItem.textContent = `Piano: ${client.trainingPlan}`;
      clientPlanList.appendChild(planItem);
    } else {
      loginMessage.textContent = "Credenziali non valide!";
    }
  }
});

// Prenotazione allenamento (solo per Clienti)
document.getElementById("schedule-btn").addEventListener("click", () => {
  const trainingDate = document.getElementById("training-date").value;
  const client = users.admin.clients.find(
    (client) => client.name === userNameSpan.textContent
  );

  if (trainingDate) {
    client.schedule.push(trainingDate);

    // Aggiungi la prenotazione all'elenco
    const trainingSchedule = document.getElementById("training-schedule");
    const scheduleItem = document.createElement("li");
    scheduleItem.textContent = `Allenamento il: ${trainingDate}`;
    trainingSchedule.appendChild(scheduleItem);
  } else {
    alert("Seleziona una data valida!");
  }
});
